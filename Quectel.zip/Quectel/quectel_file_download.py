import serial
import time

# Serial port configuration (adjust as needed)
ser = serial.Serial(port='COM6', baudrate=115200, timeout=1)

def send_at_command(command, wait_time=2):
    ser.write((command + '\r').encode())
    time.sleep(wait_time)
    response = ser.read_all().decode(errors='ignore')
    return response

def configure_pdp_context(apn):
    # Set up PDP context
    print("Configuring PDP context...")
    print(send_at_command(f'AT+QICSGP=1,1,"{apn}","","",1'))
    
    # Activate PDP context
    print("Activating PDP context...")
    print(send_at_command('AT+QIACT=1'))
    
def configure_http_service():
    # Set HTTP context ID to use the activated PDP
    print("Configuring HTTP service...")
    print(send_at_command('AT+QHTTPCFG="contextid",1'))
    # Enable HTTP response headers (for debugging purposes)
    print("Enabling response headers...")
    print(send_at_command('AT+QHTTPCFG="responseheader",0'))

def download_file_chunked(url, filename):
    url_length = len(url)
    
    # Set HTTP URL
    print("Setting HTTP URL...")
    print(send_at_command(f'AT+QHTTPURL={url_length},80'))
    print(send_at_command(url, 1))  # Send the actual URL

    # HTTP GET Request (increase timeout for large files)
    print("Initiating HTTP GET request...")
    print(send_at_command('AT+QHTTPGET=80', 10))  # 120 seconds timeout
    print(send_at_command('AT+QHTTPREADFILE="downloaded_largefile.bin",80',10))

    # # File handling: clear the file if it already exists
    # print(f"Opening {filename} for writing...")
    # print(send_at_command(f'AT+QFOPEN="{filename}",1', 2))

    # # Read the downloaded data in chunks (e.g., 16KB per chunk)
    # chunk_size = 16384  # 16KB per chunk
    # offset = 0
    # total_size = 32768  # 32KB total file size (adjust if needed)
    
    # while offset < total_size:
    #     print(f"Reading chunk from offset {offset}...")
    #     # read_command = f'AT+QHTTPREADFILE="{filename}",{offset},{chunk_size},60'
    #     read_command = f'AT+QHTTPREADFILE="{filename}",60'
    #     response = send_at_command(read_command, 10)
    #     print(response)
        
    #     # Move to the next chunk
    #     offset += chunk_size
    #     if "ERROR" in response:
    #         print("Error while reading file chunk. Exiting.")
    #         break

    # # Close the file
    # print(f"Closing {filename}...")
    # print(send_at_command('AT+QFCLOSE=1027', 2))

def check_storage():
    # Check available storage space
    print("Checking file system status...")
    response = send_at_command('AT+QFLST')
    print(response)

def main():
    # Step 1: Configure PDP context with the appropriate APN
    apn = 'airtelm2m.com.MNC045.MCC404.GPRS'  # Replace with your actual APN
    configure_pdp_context(apn)

    # Step 2: Configure HTTP service
    configure_http_service()

    # Step 3: Check file system status before downloading
    check_storage()

    # Step 4: Download file from URL in chunks and store in the EC200U filesystem
    url = 'http://172.104.244.42/builds/STMOTA/output_file_32kb_app1.bin'  # Replace with the actual URL
    filename = 'downloaded_largefile.bin'
    download_file_chunked(url, filename)

    # Step 5: Check storage after the download
    check_storage()

if __name__ == '__main__':
    main()
