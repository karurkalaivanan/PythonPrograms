import serial
import time

# Function to send AT commands and read the response
def send_at_command(serial_port, command, delay=1):
    print(f"Sending command: {command}")
    serial_port.write((command + "\r").encode())  # Send the command with a carriage return
    time.sleep(delay)  # Wait for the response
    #response = serial_port.read_all().decode()  # Read the response
    response = serial_port.read_all().decode('ISO-8859-1')
    #response = serial_port.read_all().decode('utf-8', errors='ignore')
    #response = serial_port.read_all().decode('utf-8', errors='replace')
    # while True:
    #         # Read data from serial port
    #         if serial_port.in_waiting > 0:
    #             data = serial_port.read_all().decode('ISO-8859-1')
    #             print(f"Received: {data}")
    #             break;
    #         else:
    #             time.sleep(0.1)
    print(f"Response: {response}")
    return response

# Main function to communicate with the EC200U module
def send_http_get():
    # Open serial port
    #port = serial.Serial('/dev/ttyUSB0', baudrate=115200, timeout=5)  # Change to 'COMx' on Windows
    port = serial.Serial('COM10', baudrate=115200, timeout=5)  # Change to 'COMx' on Windows

    try:
        # Initialize the module and check SIM, network, and signal strength
        send_at_command(port, "AT+CPIN?")  # Check SIM status
        send_at_command(port, "AT+CSQ")    # Check signal quality
        send_at_command(port, "AT+CREG?")  # Check network registration
        send_at_command(port, "AT+CGATT=1")  # Attach to the packet domain
        
        # Activate PDP context
        send_at_command(port, "AT+QIFGCNT=0")
        send_at_command(port, 'AT+QICSGP=1,1,"airtelm2m.com.MNC045.MCC404.GPRS","","",1')  # Replace "internet" with your APN
        send_at_command(port, "AT+QIACT=1")

        # Set HTTP configuration
        send_at_command(port, 'AT+QHTTPCFG="contextid",1')
        send_at_command(port, 'AT+QHTTPCFG="requestheader",0')

        # Specify the URL for the HTTP GET request
        url = "http://172.104.244.42:9831/gettime?gwid=NSGW0000001"  # Replace with your URL
        # url = "http://172.104.244.42/builds/STMOTA/output_file_32kb_app1.bin"
        send_at_command(port, f'AT+QHTTPURL={len(url)},60')
        time.sleep(1)  # Wait for CONNECT response
        port.write((url + '\r').encode())  # Send the URL
        time.sleep(2)

        # Initiate the HTTP GET request
        send_at_command(port, "AT+QHTTPGET=80")

        # Read the HTTP response
        send_at_command(port, "AT+QHTTPREAD")

        # Deactivate PDP context
        send_at_command(port, "AT+QIDEACT=1")
    
    finally:
        # Close the serial port
        port.close()

if __name__ == "__main__":
    send_http_get()
