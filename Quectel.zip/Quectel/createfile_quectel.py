import serial
import time

filename = "test.txt"
# Function to send AT commands and read the response
def send_at_command(serial_port, command, delay=1):
    print(f"Sending command: {command}")
    serial_port.write((command + "\r").encode())  # Send the command with a carriage return
    time.sleep(delay)  # Wait for the response
    response = serial_port.read_all().decode()  # Read the response
    print(f"Response: {response}")
    return response

def create_and_manage_file():
    # Open serial port
    port = serial.Serial('COM4', baudrate=115200, timeout=5)  # Change to 'COMx' on Windows

    try:
        # Create and open a file for writing
        send_at_command(port, 'AT+QFOPEN="test.txt",1')

        # Write "Hello World" to the file (11 characters)
        send_at_command(port, 'AT+QFWRITE=1027,11,10')
        port.write(b'Hello World\r')  # Send the data
        time.sleep(1)  # Wait for the operation to complete

        # Close the file
        send_at_command(port, 'AT+QFCLOSE=1027')

        # Open the file for reading
        send_at_command(port, 'AT+QFOPEN="test.txt",2')
        
        # Set the file pointer to the beginning of the file
        # send_at_command(port, 'AT+QFSEEK=1027,0,0')

        # Read the content of the file
        send_at_command(port, 'AT+QFREAD=1027,11')

        # Close the file after reading
        send_at_command(port, 'AT+QFCLOSE=1027')

        # Delete the file
        send_at_command(port, 'AT+QFDEL="test.txt"')

    finally:
        # Close the serial port
        port.close()

if __name__ == "__main__":
    create_and_manage_file()
