import serial
import time
from datetime import datetime

# Function to send AT command and get response
def send_at_command(serial_port, command, delay=1):
    print(f"Sending command: {command}")
    serial_port.write((command + "\r").encode())  # Send the command with carriage return
    time.sleep(delay)  # Wait for the response
    response = serial_port.read_all().decode()  # Read the response
    print(f"Response: {response}")
    return response

# Function to read system time and convert to AT+CCLK format
def get_system_time_in_cclk_format():
    # Get current system time
    now = datetime.now()

    # Format the current time into AT+CCLK="YY/MM/DD,HH:MM:SS±TZ"
    # Assuming the system's timezone is UTC+5:30 for India
    formatted_time = now.strftime('%y/%m/%d,%H:%M:%S') + "+05.5"  # Indian time zone (UTC+5:30)
    return formatted_time

# Function to set the RTC on EC200U with system time
def set_rtc_to_system_time(serial_port):
    # Get the system time in CCLK format
    date_time_str = get_system_time_in_cclk_format()
    command = f'AT+CCLK="{date_time_str}"'
    
    # Send the AT command to set the time
    response = send_at_command(serial_port, command)
    return response

# Function to read the RTC from EC200U
def read_rtc(serial_port):
    response = send_at_command(serial_port, 'AT+CCLK?')
    return response

if __name__ == "__main__":
    # Open the serial port (use appropriate COM port or USB device)
    port = serial.Serial('COM6', baudrate=115200, timeout=5)  # Use 'COMx' on Windows

    try:
        # Set RTC on the EC200U module to the system time
        set_rtc_to_system_time(port)

        # Read back the RTC to verify
        read_rtc(port)

    finally:
        port.close()  # Close the serial port
