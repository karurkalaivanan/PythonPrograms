import serial
import time

# Serial port configuration (adjust as needed)
ser = serial.Serial(port='COM10', baudrate=115200, timeout=1)

def send_at_command(command, wait_time=2):
    ser.write((command + '\r').encode())
    time.sleep(wait_time)
    response = ser.read_all().decode(errors='ignore')
    return response

def get_file_size(filename):
    # List files and sizes
    print(f"Getting file size for {filename}...")
    response = send_at_command('AT+QFLST="*"')
    
    # Check the file list for the specific file and extract its size
    for line in response.splitlines():
        if filename in line:
            # The format is typically: <file_name>,<size>,<attributes>
            file_info = line.split(",")
            if len(file_info) >= 2:
                file_size = int(file_info[1])
                print(f"File size of '{filename}': {file_size} bytes")
                return file_size
    print(f"File '{filename}' not found.")
    return None

def read_file_and_print_chars(filename):
    # Open the file for reading
    print(f"Opening {filename} for reading...")
    response = send_at_command(f'AT+QFOPEN="{filename}",0', 2)
    if "ERROR" in response:
        print("Error opening the file.")
        return
    print(response)

    # Parse file handle from the response
    file_handle = 1027 # response.split(":")[1].strip()

    # Read file in chunks and print as characters
    chunk_size = 1024  # Read 1KB per chunk (adjust if needed)
    total_bytes_read = 0
    read_data = ""
    
    while True:
        # Send the read command with the desired chunk size
        response = send_at_command(f"AT+QFREAD={file_handle},{chunk_size}",1)
        
        # Check if there is data to read
        if "CONNECT" in response:
            # Extract the data following the "CONNECT" keyword
            data_start = response.find("CONNECT") + len("CONNECT")
            data_chunk = response[data_start:].strip()  # Strip extra spaces/newlines
            read_data += data_chunk

            print(f"Read {len(data_chunk)} bytes")

            # If the data chunk is smaller than the chunk size, we have reached the end of the file
            if len(data_chunk) < chunk_size:
                break
        else:
            print("No more data to read or an error occurred")
            break
    
    send_at_command(f"AT+QFCLOSE={file_handle}",1)
    print(f"Total bytes read: {len(read_data)}")
    return read_data
    
  
def main():
    # Specify the file you want to read
    filename = 'downloaded_largefile.bin'  # Replace with your file name

    # Get and print the file size before reading
    file_size = get_file_size(filename)
    if file_size is None:
        print(f"File '{filename}' not found. Exiting.")
        return

    # Read the file and print as characters
    read_file_and_print_chars(filename)

if __name__ == '__main__':
    main()
