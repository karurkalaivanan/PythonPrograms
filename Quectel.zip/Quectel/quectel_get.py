import serial
import time
from datetime import datetime

# Define commands array
init_AT_commands = [
    "AT|OK|1000",
    "AT+CPIN?|OK|1000",
    "AT+CSQ|OK|2000",
    "AT+CREG?|0,1|1000",
    "AT+QIDEACT=1|OK|2000",
    "AT+QHTTPCFG=\"contextid\",1|OK|2000",
    "AT+QHTTPCFG=\"responseheader\",0|OK|2000",
    "AT+QICSGP=1,1,\"airtelm2m.com.MNC045.MCC404.GPRS\",\"\",\"\",1|OK|5000",
    "AT+QIACT=1|OK|5000",
    "AT+QIACT?|OK|1000",
    "AT+QHTTPURL=48,60|CONNECT|2000",
    "http://api.ms-tech.in/v2/gettime?gwid=NSGW900001|OK|1000",
    "AT+QHTTPGET=80|200|5000",
    "AT+QHTTPREAD|CONNECT|5000"
]

get_AT_commands = [
    "AT+QHTTPGET=80|200|5000",
    "AT+QHTTPREAD|OK|5000"
]
# Initialize serial communication
serial_port = serial.Serial(
    port='COM5',  # Change to the appropriate port
    baudrate=115200,
    timeout=1  # Read timeout in seconds
)

def print_time():
  current_time = datetime.now()
  # Print the system time
  print("Current system time:", current_time.strftime("%H:%M:%S"))
  
def send_command(command, expected_response, timeout_ms):
    """Send AT command and wait for response."""
    try:
        # Send the command
        serial_port.write((command + '\r\n').encode())
        print(f"Sent: {command}")

        # Wait for response
        start_time = time.time()
        timeout_sec = timeout_ms / 1000.0

        while time.time() - start_time < timeout_sec:
            # Read response
            if serial_port.in_waiting > 0:
                response = serial_port.read(serial_port.in_waiting).decode().strip()
                print(f"Received: {response}")

                # Check if expected response is present
                if expected_response in response:
                    print("Response matched!")
                    return True
                time.sleep(0.1)
        print("Timeout or no valid response.")
        return False

    except Exception as e:
        print(f"Error: {e}")
        return False

def process_commands():
    """Process the commands array."""
    for command_line in init_AT_commands:
        # Parse command, expected response, and timeout
        parts = command_line.split('|')
        command = parts[0]
        expected_response = parts[1]
        timeout_ms = int(parts[2])

        # Send command and handle response
        success = send_command(command, expected_response, timeout_ms)
        if not success:
            print(f"Failed to execute command: {command}")
            break

# Main entry point
if __name__ == "__main__":
    if serial_port.is_open:
        print_time()
        process_commands()
        serial_port.close()
        print_time()
    else:
        print("Failed to open serial port.")
