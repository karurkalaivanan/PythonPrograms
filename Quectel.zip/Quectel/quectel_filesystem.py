import serial
import time

# Function to send AT commands and capture response
def send_at_command(serial_port, command, delay=1):
    print(f"Sending command: {command}")
    serial_port.write((command + "\r").encode())  # Send the command with a carriage return
    time.sleep(delay)  # Wait for the response
    response = serial_port.read_all().decode()  # Read the response
    print(f"Response: {response}")
    return response

# Function to open a file and extract the file handle
def open_file_and_get_handle(port, filename):
    response = send_at_command(port, f'AT+QFOPEN="{filename}",1')  # Open file in append mode
    # Look for '+QFOPEN:' in the response
    if "+QFOPEN:" in response:
        handle = response.split("+QFOPEN:")[1].split("\n")[0].strip()  # Extract the handle
        print(f"File handle: {handle}")
        return int(handle)  # Convert to integer
    else:
        print("Failed to get file handle")
        return None

# Main function
def create_and_manage_file(filename):
    # Open serial port
    port = serial.Serial('COM6', baudrate=115200, timeout=5)  # Change to 'COMx' on Windows

    try:
        # Open the file and get the handle
        file_handle = open_file_and_get_handle(port, filename)
        if file_handle is None:
            return

        # Write "Hello World" to the file using the file handle
        send_at_command(port, f'AT+QFWRITE={file_handle},11,100')
        port.write(b'Hello World\r')  # Send the data
        time.sleep(1)  # Wait for the operation to complete

        # Close the file
        send_at_command(port, f'AT+QFCLOSE={file_handle}')
        
        # Open the file for reading
        send_at_command(port, f'AT+QFOPEN="{filename}",2')
        
        # Read the content of the file
        send_at_command(port, f'AT+QFREAD={file_handle},11')
        
        # Close the file after reading
        send_at_command(port, f'AT+QFCLOSE={file_handle}')

    finally:
        # Close the serial port
        port.close()

if __name__ == "__main__":
    filename = "test.txt"  # Specify the filename
    create_and_manage_file(filename)
